// Fill out your copyright notice in the Description page of Project Settings.

#include "EVRootWidget.h"
#include "EnhanceVocabulary/EVGameInstance.h"
#include "EnhanceVocabulary/EVAppPlayerController.h"

#include "Kismet/KismetSystemLibrary.h"

// Defining consts fpr the Color dynamic material instance params
const FName UEVRootWidget::SphereColorParam(TEXT("SphereColor"));
const FName UEVRootWidget::OpacityParam(TEXT("Opacity"));

void UEVRootWidget::NativeOnInitialized()
{
    Super::NativeOnInitialized();

    SetupConnectionErrorInfo(EVConnectionErrorInfo);

    EVGameInstance = Cast<UEVGameInstance>(GetGameInstance());
    EVAppPlayerController = Cast<AEVAppPlayerController>(GetOwningPlayer());

    if (Image_ConnectionState)
    {
        ConnectionMID = Image_ConnectionState->GetDynamicMaterial();
        ConnectionMID->SetScalarParameterValue(OpacityParam, 1.0f);
    }

    if (EVGameInstance)
    {
        EVGameInstance->OnConnectionStateChanged.AddDynamic(this, &ThisClass::HandleOnConnectionStateChanged);
        HandleOnConnectionStateChanged(EVGameInstance->GetConnectionState());
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("EVGameInstance in EVRootWidget.cpp is nullptr"));
    }

    if (EVAppPlayerController)
    {
        EVAppPlayerController->OnWidgetsErrorResolved.AddDynamic(this, &ThisClass::HandleOnErrorMessageResolved);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("EVAppPlayerController in EVRootWidget.cpp is nullptr"));
    }

    bIsAddWordActivated_internal = false;
    bIsReviewWordsActivated_internal = false;
    bIsPopupSettingsActivated_internal = false;
    bIsImportExportActivated_internal = false;
    bIsAppSettingsActivated_internal = false;

    if (AddWord)
    {
        AddWord->OnError.AddDynamic(this, &ThisClass::HandleOnAnyWidgetErrorDetected);
        if (IEVWidgetCommonEvents* WidgetCommonEvents = Cast<IEVWidgetCommonEvents>(AddWord))
        {
            if (FOnWidgetInteractionDisabled* WidgetInputsDisabledEvent =
                    WidgetCommonEvents->GetWidgetInteractionDisabledEvent())
            {
                WidgetInputsDisabledEvent->AddDynamic(this, &ThisClass::HandleOnAnyWidgetControlsDisabled);
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("FOnWidgetInteractionDisabled in EVRootWidget.cpp is nullptr"));
            }

            if (FOnLoadingDataTriggerred* LoadingDataTriggerredEvent = WidgetCommonEvents->GetLoadingSpinnerEvent())
            {
                LoadingDataTriggerredEvent->AddDynamic(this, &ThisClass::HandleLoadingSpinner);
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("FOnLoadingDataTriggerred in EVRootWidget.cpp is nullptr"));
            }

            if (FOnActionRequested* ActionRequested = WidgetCommonEvents->GetRequestedActionInfo())
            {
                ActionRequested->AddDynamic(this, &ThisClass::HandleOnActionRequested);
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("FOnActionRequested in EVRootWidget.cpp is nullptr"));
            }
        }
    }

    if (ReviewWords)
    {
        ReviewWords->OnWordEntryWidgetControlsButtonPressed.AddDynamic(
            this, &ThisClass::HandleOnWordEntryWidgetControlsActivated);
        ReviewWords->OnVocabularyValueActionRequested.AddDynamic(this,
                                                                 &ThisClass::HandleVocabularyValueActionRequested);
        ReviewWords->OnFiltersRequested.AddDynamic(this, &ThisClass::HandleVocabularyFiltersRequested);
    }

    if (Settings_SelectWebProviders)
    {
        // Binding the EVGameInstance handler to catch and pass the EVWebProviders to the Storage functions
        Settings_SelectWebProviders->OnWebProvidersSelectionChangedSettingsWidget.AddDynamic(
            AddWord, &UEVAddWordWidget::HandleWebProvidersChanged);
        Settings_SelectWebProviders->OnVocabularyLanguagePreferencesChangedSettingsWidget.AddUniqueDynamic(
            this, &ThisClass::HandleVocabularyLanguagePreferencesChanged);
    }

    if (ImportExportDB)
    {
        ImportExportDB->OnImportExportDownloadDBIssued.AddDynamic(
            this, &ThisClass::HandleOnImportExportDownloadDBOperationIssued);
    }

    if (PopUpSettings)
    {
        PopUpSettings->OnNotificationSettingsChanged.AddDynamic(this, &ThisClass::HandlePopUpIntervalSelected);
    }

    if (Button_Menu)
    {
        Button_Menu->OnPressed.AddDynamic(this, &ThisClass::ButtonMenuPressed);
    }

    if (MainMenu)
    {
        MainMenu->OnMenuButtonsPressed.AddDynamic(this, &ThisClass::HandleMenuButtonsPressed);
        MainMenu->OnQuitButtonPressed.AddDynamic(this, &ThisClass::HandleQuitButtonPressed);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to instantiate WBP_MainMenu"));
    }
}

void UEVRootWidget::NativePreConstruct()
{
    Super::NativePreConstruct();
}

void UEVRootWidget::NativeConstruct()
{
    Super::NativeConstruct();

    if (WidgetSwitcher_Main && NoMenu)
    {
        WidgetSwitcher_Main->SetActiveWidget(NoMenu);
        bIsAnyMenuActivated = false;
        MenuSwitcherCount = 0;
    }
}

void UEVRootWidget::ButtonMenuPressed()
{
    if (MenuSwitcherCount == 0)
    {
        WidgetSwitcher_Main->SetActiveWidget(MainMenu);
        MenuSwitcherCount = 1;
    }

    else
    {
        if (bIsAnyMenuActivated)
        {
            if (bIsAddWordActivated_internal)
            {
                HandleOnlineDependantWidgetsActivation(AddWord, bIsAppOnline);
                HandleWidgetControlsState(AddWord, bIsAppOnline);
                MenuSwitcherCount = 0;
            }

            else if (bIsReviewWordsActivated_internal)
            {
                WidgetSwitcher_Main->SetActiveWidget(ReviewWords);
                MenuSwitcherCount = 0;
            }

            else if (bIsAppSettingsActivated_internal)
            {
                WidgetSwitcher_Main->SetActiveWidget(Settings_SelectWebProviders);
                MenuSwitcherCount = 0;
            }

            else if (bIsImportExportActivated_internal)
            {
                WidgetSwitcher_Main->SetActiveWidget(ImportExportDB);
                MenuSwitcherCount = 0;
            }

            else if (bIsPopupSettingsActivated_internal)
            {
                WidgetSwitcher_Main->SetActiveWidget(PopUpSettings);
                MenuSwitcherCount = 0;
            }
        }

        else
        {
            WidgetSwitcher_Main->SetActiveWidget(NoMenu);
            MenuSwitcherCount = 0;
        }
    }
}

void UEVRootWidget::HandleMenuButtonsPressed(bool bIsAddWordActivated, bool bIsReviewWordsActivated,
                                             bool bIsPopupSettingsActivated, bool bIsImportExportActivated,
                                             bool bIsAppSettingsActivated)
{
    bIsAddWordActivated_internal = bIsAddWordActivated;
    bIsReviewWordsActivated_internal = bIsReviewWordsActivated;
    bIsPopupSettingsActivated_internal = bIsPopupSettingsActivated;
    bIsImportExportActivated_internal = bIsImportExportActivated;
    bIsAppSettingsActivated_internal = bIsAppSettingsActivated;

    bIsAnyMenuActivated = true;

    if (bIsAddWordActivated)
    {
        HandleOnlineDependantWidgetsActivation(AddWord, bIsAppOnline);
        HandleWidgetControlsState(AddWord, bIsAppOnline);
        MenuSwitcherCount = 0;
    }

    else if (bIsReviewWordsActivated)
    {
        WidgetSwitcher_Main->SetActiveWidget(ReviewWords);
        ReviewWords->RefreshReview();
        MenuSwitcherCount = 0;
    }

    else if (bIsPopupSettingsActivated)
    {
        WidgetSwitcher_Main->SetActiveWidget(PopUpSettings);
        MenuSwitcherCount = 0;
    }

    else if (bIsAppSettingsActivated)
    {
        WidgetSwitcher_Main->SetActiveWidget(Settings_SelectWebProviders);
        MenuSwitcherCount = 0;
    }

    else if (bIsImportExportActivated)
    {
        WidgetSwitcher_Main->SetActiveWidget(ImportExportDB);
        MenuSwitcherCount = 0;
    }
}

void UEVRootWidget::SetupConnectionErrorInfo(FEVErrorInfo& ConnectionErrorInfo)
{
    ConnectionErrorInfo.Source = EEVErrorSource::ConnectionModule;
    ConnectionErrorInfo.Type = EEVErrorType::ConnectionError;
    ConnectionErrorInfo.Message = FText::FromString(
        TEXT("Failed to connect to the WEB. You are Offline and some functionality may not be available"));
}

bool UEVRootWidget::HandleWidgetControlsState(IEVWidgetControllable* Widget, bool bIsConnectionStatusOnline)
{
    if (Widget)
    {
        if (bIsConnectionStatusOnline == true && Widget->GetControlsEnabled() == true)
        {
            return true;
        }
        else if (bIsConnectionStatusOnline == false && Widget->GetControlsEnabled() == true)
        {
            Widget->SetControlsEnabled(false);
            return false;
        }
        else if (bIsConnectionStatusOnline == true && Widget->GetControlsEnabled() == false)
        {
            Widget->SetControlsEnabled(true);
            return true;
        }

        return false;
    }

    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to get instance of IEVWidgetControllable"));
        return false;
    }
}

void UEVRootWidget::HandleOnlineDependantWidgetsActivation(UUserWidget* Widget, bool bIsConnectionStatusOnline)
{
    if (Widget)
    {
        if (bIsConnectionStatusOnline)
        {
            WidgetSwitcher_Main->SetActiveWidget(Widget);
        }
        else
        {
            HandleOnConnectionErrorDetected();
        }
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to get instance of UUserWidget"));
    }
}

void UEVRootWidget::HandleOnErrorMessageResolved(const FEVErrorInfo& EVErrorInfo)
{
    EEVErrorSource EVErrorSource = EVErrorInfo.Source;
    EEVErrorType EEVErrorType = EVErrorInfo.Type;

    switch (EVErrorSource)
    {
    case EEVErrorSource::AddWord:
        if (EEVErrorType == EEVErrorType::SearchError)
        {
            if (!AddWord)
            {
                return;
            }
            AddWord->SetInputEnabled(true);
        }
        break;
    default:
        break;
    }
}

void UEVRootWidget::HandleQuitButtonPressed()
{
    UKismetSystemLibrary::QuitGame(GetWorld(), GetOwningPlayer(), EQuitPreference::Quit, false);
}

void UEVRootWidget::HandleOnAnyWidgetErrorDetected(const FEVErrorInfo& WidgetErrorInfo)
{
    OnRootWidgetError.Broadcast(WidgetErrorInfo);
}

void UEVRootWidget::HandleOnConnectionErrorDetected()
{
    OnRootWidgetError.Broadcast(EVConnectionErrorInfo);
}

void UEVRootWidget::HandleOnAnyWidgetControlsDisabled(bool bAreControlsEnabled, const FString& WidgetName)
{
    if (!bAreControlsEnabled)
    {
        if (EVConnectionState != EEVConnectionState::Online)
        {
            HandleOnConnectionErrorDetected();
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("The %s widget controls disabled but we are Online"), *WidgetName);
        }
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("The %s widget controls were not disabled"), *WidgetName);
    }
}

void UEVRootWidget::HandleOnConnectionStateChanged(EEVConnectionState State)
{
    switch (State)
    {
    case EEVConnectionState::Offline:
        UE_LOG(LogTemp, Warning, TEXT("We are Offline"));
        bIsAppOnline = false;
        HandleWidgetControlsState(AddWord, bIsAppOnline);
        HandleOnConnectionErrorDetected();
        HandleConnectionImageColor(ConnectionMID, State);
        break;
    case EEVConnectionState::Connecting:
        bIsAppOnline = false;
        HandleWidgetControlsState(AddWord, bIsAppOnline);
        HandleOnConnectionErrorDetected();
        HandleConnectionImageColor(ConnectionMID, State);
        UE_LOG(LogTemp, Warning, TEXT("We are Connecting"));
        break;
    case EEVConnectionState::Online:
        bIsAppOnline = true;
        HandleWidgetControlsState(AddWord, bIsAppOnline);
        HandleConnectionImageColor(ConnectionMID, State);
        UE_LOG(LogTemp, Warning, TEXT("We are Online"));
        break;
    default:
        HandleConnectionImageColor(ConnectionMID, State);
        break;
    }
}

void UEVRootWidget::HandleLoadingSpinner(bool bRenderLoadingSpinner)
{
    OnLoadingDataTriggerred.Broadcast(bRenderLoadingSpinner);
}

void UEVRootWidget::HandleOnActionRequested(const FEVRequestedActionInfo& RequestedActionInfo)
{
    OnActionRequested.Broadcast(RequestedActionInfo);
}

void UEVRootWidget::HandleOnWordEntryWidgetControlsActivated(const FEVWordEntryActionInfo& WordEntryActionInfo)
{
    OnWordEntryWidgetControlsActivated.Broadcast(WordEntryActionInfo);
}

void UEVRootWidget::HandleOnImportExportDownloadDBOperationIssued(
    const FEVFileOperationInfo& FileOperationInfoFromSelectorWidget)
{
    OnImportExportDownloadDBOperationIssued.Broadcast(FileOperationInfoFromSelectorWidget);
}

void UEVRootWidget::HandlePopUpIntervalSelected(const FEVPopUpSettingsInfo& PopUpSettingsFromWidget)
{
    OnPopUpIntervalSelectedFromSettings.Broadcast(PopUpSettingsFromWidget);
}

void UEVRootWidget::HandleReviewWordsRefresh()
{
    if (!ReviewWords)
    {
        UE_LOG(LogTemp, Error, TEXT("Cannot refresh Review Words: ReviewWords is null."));

        return;
    }

    ReviewWords->RefreshReview();
}

void UEVRootWidget::HandleOpenReviewWordsForNotification(const FString& Word)
{
    if (!WidgetSwitcher_Main || !ReviewWords)
    {
        UE_LOG(LogTemp, Error, TEXT("Cannot open Review Words from notification: required widget is null."));
        return;
    }

    bIsAnyMenuActivated = true;
    bIsAddWordActivated_internal = false;
    bIsReviewWordsActivated_internal = true;
    bIsPopupSettingsActivated_internal = false;
    bIsImportExportActivated_internal = false;
    bIsAppSettingsActivated_internal = false;
    MenuSwitcherCount = 0;

    WidgetSwitcher_Main->SetActiveWidget(ReviewWords);
    ReviewWords->SetSearchWord(Word);
}

void UEVRootWidget::HandleVocabularyValueActionRequested(const FEVVocabularyValueActionRequest& Request)
{
    OnVocabularyValueActionRequested.Broadcast(Request);
}

void UEVRootWidget::HandleOpenAddWordWithWord(const FString& Word)
{
    if (!WidgetSwitcher_Main || !AddWord)
    {
        return;
    }

    bIsAnyMenuActivated = true;
    bIsAddWordActivated_internal = true;
    bIsReviewWordsActivated_internal = false;
    bIsPopupSettingsActivated_internal = false;
    bIsImportExportActivated_internal = false;
    bIsAppSettingsActivated_internal = false;
    MenuSwitcherCount = 0;

    HandleOnlineDependantWidgetsActivation(AddWord, bIsAppOnline);
    HandleWidgetControlsState(AddWord, bIsAppOnline);
    AddWord->SetWordInput(Word);
}

void UEVRootWidget::HandleConnectionImageColor(TObjectPtr<UMaterialInstanceDynamic> MaterialInstanceDynamic,
                                               EEVConnectionState ConnectionState)
{
    if (MaterialInstanceDynamic)
    {
        switch (ConnectionState)
        {
        case EEVConnectionState::Online:
            MaterialInstanceDynamic->SetVectorParameterValue(SphereColorParam,
                                                             FLinearColor(FColor(0x00, 0xBC, 0x00, 0xFF)));
            break;
        case EEVConnectionState::Connecting:
            MaterialInstanceDynamic->SetVectorParameterValue(SphereColorParam,
                                                             FLinearColor(FColor(0xE7, 0xE7, 0x00, 0xFF)));
            break;
        case EEVConnectionState::Offline:
            MaterialInstanceDynamic->SetVectorParameterValue(SphereColorParam,
                                                             FLinearColor(FColor(0xDA, 0x00, 0x00, 0xFF)));
            break;
        default:
            MaterialInstanceDynamic->SetVectorParameterValue(SphereColorParam,
                                                             FLinearColor(FColor(0xDA, 0x00, 0x00, 0xFF)));
            break;
        }
    }
    else
    {
        UE_LOG(LogTemp, Error,
               TEXT("TObjectPtr<UMaterialInstanceDynamic> MaterialInstanceDynamic is nullptr in WBP_RootWidget"));
    }
}

void UEVRootWidget::HandleApplyResolvedPopUpSettings(const FEVPopUpSettingsInfo& PopUpSettingsInfo)
{
    if (!PopUpSettings)
    {
        UE_LOG(LogTemp, Error, TEXT("Cannot apply resolved pop-up settings: PopUpSettings is null."));

        return;
    }

    PopUpSettings->SetSelectedSettings(PopUpSettingsInfo);
}

void UEVRootWidget::HandleWordEntryChanged(const FEVWordEntryActionInfo& WordEntryActionInfo)
{
    if (!ReviewWords)
    {
        return;
    }

    switch (WordEntryActionInfo.ActionType)
    {
    case EEVWordEntryActionType::SaveEditedEntry:
        ReviewWords->UpdateDisplayedWordEntry(WordEntryActionInfo.EntryInfo);
        break;

    case EEVWordEntryActionType::DeleteEntry:
        ReviewWords->RemoveDisplayedWordEntry(WordEntryActionInfo.EntryInfo);
        break;

    default:
        break;
    }
}

void UEVRootWidget::HandleVocabularyFiltersRequested()
{
    OnVocabularyFiltersRequested.Broadcast();
}

void UEVRootWidget::HandleVocabularyFiltersApplied(const FEVVocabularyQueryCriteria& Criteria)
{
    if (ReviewWords)
    {
        ReviewWords->ApplyQueryCriteria(Criteria);
    }
}

void UEVRootWidget::HandleVocabularyLanguagePreferencesChanged(
    const FEVVocabularyLanguagePreferences& Preferences)
{
    OnVocabularyLanguagePreferencesChanged.Broadcast(Preferences);
}

void UEVRootWidget::HandleVocabularyLanguagePreferencesApplied(
    const FEVVocabularyLanguagePreferences& Preferences)
{
    if (Settings_SelectWebProviders)
    {
        Settings_SelectWebProviders->ApplyVocabularyLanguagePreferences(Preferences);
    }

    if (ReviewWords)
    {
        ReviewWords->RefreshReview();
    }
}
