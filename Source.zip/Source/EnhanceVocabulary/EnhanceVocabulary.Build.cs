// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class EnhanceVocabulary : ModuleRules
{
	public EnhanceVocabulary(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
	
		PublicDependencyModuleNames.AddRange(new string[] { 
			"Core", 
			"CoreUObject", 
			"Engine", 
			"InputCore", 
			"EnhancedInput",
			"UMG",
			"EnhanceVocabularyCore",
            "EnhanceVocabularyWeb",
            "EnhanceVocabularyStorage",
            "EnhanceVocabularyDevice",
            "Json"
        });

		PrivateDependencyModuleNames.AddRange(new string[] {
            "Core",
            "CoreUObject",
            "Engine",
            "InputCore",
            "EnhancedInput",
            "UMG",
            "Slate", 
			"SlateCore",
            "EnhanceVocabularyCore",
            "EnhanceVocabularyWeb",
            "EnhanceVocabularyStorage",
            "EnhanceVocabularyDevice",
            "Json"
        });

		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true
	}
}
